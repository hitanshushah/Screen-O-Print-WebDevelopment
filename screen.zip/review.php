<!Doctype html>
<html>
<link rel="stylesheet" href="http:www.w3schools.com/lib/w3.css">
<script src="code.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
<head>
<title>Screen-O-Print | Banner Printing</title>
<meta name="description" content="Printing designs and different size banners at reasonable rates.">
<meta name="keywords" content="Printing, print, product, service, quaity, banner">
<meta name="robots" content="index,follow">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel = "icon" href = "images/logo5.png" type = "image/x-icon">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-168650451-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-168650451-1');
</script> 
</head>

<style type="text/css">
    * {
        box-sizing: border-box;
    }
</style>
<body >
<div id="loader" class="center"></div>
<nav>    
        <img alt="logo" class="logo" src="images/logo.png">
 <ul>
   <li class="items">     <a href="index.html" >HOME</a></li>
      <li class="items">      <a href="product.html">PRODUCTS</a> </li> 
      <li class="items">     <a href="service.html">SERVICES</a> </li>
      <li class="items">      <a href="contact.html">CONTACT US</a></li>
      <li class="items">     <a href="about.html" >ABOUT US</a> </li>  
   
  <li class="btn"> <a href="#"><i class="fas fa-bars"></i></a></li>
     </ul>
</nav>
 
<div class="space" style="height: 20%"><br><br></div>
<h1>Reviews</h1>

 
<br>
<br>
<?php include 'process1.php'; ?>
<?php include 'connection.php'; ?>
<?php

?>
<div class="row container" align="center">
<div class="col-md-4 ">
 <h3><b>Rating & Reviews</b></h3>
  <div class="row">
  
    <div class="col-md-6">
      <h3 align="center"><b><?php echo round($AVGRATE,1);?></b> <i class="fa fa-star" data-rating="2" ></i></h3>
      <h4 ><?=$Total;?> reviews</h4>
    </div>
    
  </div>
  <div class="row">
    <div class="col-md-12" align="left" > 
    <?php
      $review = mysqli_query($connection,"SELECT review,rate,fname,pname from stars  ");
      while($db_review= mysqli_fetch_array($review)){
    ?>
        <h4><?=$db_review['rate'];?> <i class="fa fa-star" data-rating="2"></i> by <span><?=$db_review['fname'];?></span> &nbsp; <h5>Product :<?=$db_review['pname'];?></h5></h4>
        <p><?=$db_review['review'];?></p>
        <br><hr>
        <?php
      }
      ?>
        

        
   
    </div>
  </div>
</div>
</div>

<hr class="line" style="width: 50%; margin-width:2px; background-color: black"><br>
<div class="foot">
    <div class="part" style="background-color:peru; max-height: 100%;">
    <img alt="logo" src="images/logo.png" class="head" style="width: 50%">
    <p class="matter">
      <br>
<i class="fa fa-mobile" ><a href="tel: 9869031638" >   +91 9869031638</a></i><br><br>
<i class="fa fa-envelope" > <a href = "mailto:shah_atul2002@yahoo.co.in">  shah_atul2002@yahoo.co.in</a></i><br><br>
<i class="fa fa-clock-o">   Monday-Friday : 10am-6pm</i><br><br>
<i class="fa fa-home" >  4-Joshi Chawl, Opp. Neeldhara Apt, DevidasLane, S.V.P. Road, Borivali-West, Mumbai-400103</i>
    </p>
  </div>
  <div class="part1" style="background-color:peru">
    <h2 class="head"><b>Site Map</b></h2>
    <a href="index.html" class="matter">Home</p></a>
    <a href="product.html"  class="matter">Products</p></a>
    <a href="service.html" class="matter">Services</p></a>
    <a href="contact.html" class="matter">Contact Us</p></a>
    <a href="about.html" class="matter">About Us</p></a>
  </div>
  <div class="part2" style="background-color:peru">
    <h2 class="head"><b>Find Us</b></h2>
     <a href="https://www.google.com/maps/place/Neeldhara+Apartment,+Devidas+Cross+Ln,+Prem+Nagar,+Borivali+West,+Mumbai,+Maharashtra+400091/@19.2371725,72.8509338,18.28z/data=!4m5!3m4!1s0x3be7b12755dfe673:0xbbbece8cf00d9f52!8m2!3d19.2374622!4d72.8514314"><img alt="map" class="trick" src="images/map.png"></a>
  </div>
  <div class="bottom">
    <p>asdfghjkl</p>
    Developed by: <abbr class="bun" title="Mob: 8169800983"><a href="tel: 8169800983">Hitanshu Shah</a></abbr>
    , Logo Designed by: <abbr class="man" title="Mob: 9969208155"><a href="tel: 9969208155">Manasvi Gokhlani</a></abbr><br> 
    <p>asdfghjkl</p></div>
  </div>
</div>
<button id="myBtn"><a href="#top" style="color: white; text-decoration: none;">Top</a></button>
<script type="text/javascript">document.onreadystatechange=function(){if(document.readyState!=="complete"){document.querySelector("body").style.visibility="hidden";document.querySelector("#loader").style.visibility="visible"}else{document.querySelector("#loader").style.display="none";document.querySelector("body").style.visibility="visible"}}</script>
<script type="text/javascript">$(document).ready(function(){$('.btn').click(function(){$('.items').toggleClass("show");$('ul li').toggleClass("hide")})})</script>
    
    <script src="item.js"></script>
    
</body>
</html>